@echo off
call .venv\Scripts\activate.bat
echo Open http://127.0.0.1:8000/docs in your browser
python -m uvicorn api.main:app --reload
