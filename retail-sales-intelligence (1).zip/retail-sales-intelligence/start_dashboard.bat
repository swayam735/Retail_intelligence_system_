@echo off
call .venv\Scripts\activate.bat
python -m streamlit run dashboard\app.py
