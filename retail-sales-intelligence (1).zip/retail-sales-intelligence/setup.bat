@echo off
REM Windows: one-time setup. Double-click or run in Command Prompt.
python --version || (echo Python not found. Install Python 3.11+ from python.org and tick "Add to PATH" & pause & exit /b 1)
python -m venv .venv
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
echo.
echo Setup complete. Now run:  run_all.bat
pause
