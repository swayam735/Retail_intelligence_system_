# Retail Sales Intelligence System

End-to-end data science project: **SQL data warehouse → machine learning → REST API, interactive dashboard and Power BI.**
One command builds everything; automated tests gate model quality.

```bash
pip install -r requirements.txt
python run_pipeline.py          # ~1 min: data → warehouse → 3 ML models → Power BI export
python -m pytest -q             # 25 tests: integrity, leakage, API, dashboard, model-quality gates
streamlit run dashboard/app.py  # http://localhost:8501
uvicorn api.main:app --reload   # http://127.0.0.1:8000/docs
```
Windows: double-click `setup.bat`, then `run_all.bat`.  macOS/Linux: `make setup && make run`.
Full walkthrough in Hinglish: [`GUIDE_HINGLISH.md`](GUIDE_HINGLISH.md).

## Architecture

```mermaid
flowchart LR
    G[Data generator<br/>synthetic, messy] --> E[ETL + cleaning]
    E --> W[(SQL star schema<br/>fact_sales + 4 dims<br/>+ views)]
    W --> F[Forecast<br/>XGBoost + Ridge blend]
    W --> C[Churn<br/>snapshot XGBoost]
    W --> R[RFM segments<br/>K-Means]
    F & C & R -->|predictions written back| W
    W --> A[FastAPI]
    W --> D[Streamlit dashboard]
    W --> P[Power BI<br/>Excel/CSV export]
```

Predictions are written back into SQL, so the API, the dashboard and Power BI all read the **same views** — business logic lives in one place.

## Results (synthetic data, seeded, reproducible)

**Sales forecast** — MAPE on a 60-day holdout never used for tuning or blend-weight selection (lower is better)

| Method | MAPE |
|---|---|
| Naive (yesterday) | 18.45% |
| Seasonal naive (same day last week) | 16.06% |
| 7-day moving average | 12.84% |
| Same-weekday 4-week average | 11.95% |
| **Blend: tuned XGBoost + Ridge (final)** | **9.69%** |

* 47.5% lower error than naive; 19.0% lower than the strongest baseline.
* Realistic multi-step setting (all 60 days forecast at once, recursively): **11.97%** vs 16.01% for the best multi-step baseline.
* Approximate 80% prediction interval, calibrated on the multi-step backtest residuals.

**Churn** — snapshot design (train on features at *T-90d*, label = no order in next 90d, score as of *T*), 5-fold CV

* AUC 0.946 overall (recency-only baseline: 0.948) · precision 0.93 / recall 0.82 on the churn class.
* On customers still active at the snapshot: AUC 0.70 (recency-only baseline 0.71).

**RFM segmentation** — K-Means on standardised RFM → 6 business segments.

### Honest notes (read before an interview)
* **The data is synthetic.** It is generated with weekly/yearly seasonality, promotions, trend, dirty rows, and customers whose purchase rate fades over ~120 days before they churn.
* **The churn model does not beat a one-feature "days since last order" baseline** on this data — recency dominates. The project reports that comparison on purpose; the value is the leakage-safe, deployed scoring pipeline, not an accuracy lift.
* The forecast gain over baselines is real *on this simulator*; on real data expect smaller gains and add real holiday/promo calendars.
* SQLite keeps it zero-install; swap `python/db_connector.py` for SQL Server/Postgres for a shared deployment.
* `docker-compose.yml` is provided but was **not** run in the authoring environment (no Docker available there).
* DAX measures in `powerbi/measures.dax` are standard patterns but were not executed in Power BI Desktop by the authoring environment.

## Engineering practices
* **No leakage**: one `feature_row()` builds training and recursive-forecast features; a unit test proves features don't change when future values change. Blend weight chosen on a validation window, evaluated on an untouched test window; XGBoost tuned with `TimeSeriesSplit`.
* **Quality gates in CI**: tests fail if the forecast stops beating *every* baseline, or churn AUC < 0.85.
* **Security**: all SQL values are bound parameters; path/query params are typed (injection test included).
* **Config**: `RETAIL_DB_PATH` env var overrides the DB location. Structured logging everywhere. Non-zero exit codes on failure.
* **CI**: GitHub Actions runs pipeline + tests on every push and uploads the Power BI workbook.

## API
| Endpoint | Purpose |
|---|---|
| `GET /health` | liveness + latest data date |
| `GET /forecast?days=30&include_backtest=false` | forecast with 80% interval |
| `GET /customers/{id}` | churn risk + RFM segment |
| `GET /customers/at-risk?limit=20` | still-active customers most likely to churn |
| `GET /kpis/monthly?year=2024` | revenue / orders / AOV |
| `GET /segments/summary`, `GET /metrics` | segments, model metrics |

## Use your own data
Put `customers.csv, products.csv, stores.csv, sales.csv` (same columns as `data/generate_data.py` outputs) in `data/raw/`, then `python run_pipeline.py --skip-generate`.

## Structure
```
data/generate_data.py        synthetic data generator          api/main.py          FastAPI service
sql/schema, sql/etl          star schema + cleaning ETL        dashboard/app.py     Streamlit dashboard
sql/analytics                window-function queries, views    powerbi/             export script, DAX, guide
python/forecasting|churn_model|segmentation   ML modules       tests/               25 tests
python/db_connector.py       the only DB-specific file         run_pipeline.py      orchestrator
```
