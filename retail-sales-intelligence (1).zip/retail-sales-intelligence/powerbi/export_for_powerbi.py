"""
export_for_powerbi.py
----------------------
Exports every table/view Power BI needs.

    powerbi/exports/retail_powerbi_data.xlsx   <- RECOMMENDED: one workbook, one sheet per
                                                  table, real date types. In Power BI:
                                                  Get Data -> Excel workbook -> tick all sheets.
    powerbi/exports/<table>.csv                <- same data as individual CSVs (optional)

Usage:  python powerbi/export_for_powerbi.py
"""

import logging
import sys
from pathlib import Path

import pandas as pd

sys.path.append(str(Path(__file__).resolve().parents[1] / "python"))
from db_connector import read_query  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")
log = logging.getLogger("export")

OUT_DIR = Path(__file__).parent / "exports"
TABLES = [
    "fact_sales", "dim_date", "dim_customer", "dim_product", "dim_store",
    "vw_monthly_kpi_summary", "vw_daily_sales", "vw_product_performance", "vw_customer_360",
    "ml_sales_forecast", "ml_customer_churn", "ml_customer_segments", "ml_model_metrics",
]
DATE_COLUMNS = {"full_date", "signup_date", "forecast_date", "sales_date"}


def main() -> None:
    OUT_DIR.mkdir(exist_ok=True)
    xlsx_path = OUT_DIR / "retail_powerbi_data.xlsx"
    with pd.ExcelWriter(xlsx_path, engine="openpyxl", datetime_format="YYYY-MM-DD") as writer:
        for table in TABLES:
            df = read_query(f"SELECT * FROM {table}")  # table names come from the constant list above
            df.to_csv(OUT_DIR / f"{table}.csv", index=False)
            for col in DATE_COLUMNS & set(df.columns):
                df[col] = pd.to_datetime(df[col], errors="coerce")
            df.to_excel(writer, sheet_name=table[:31], index=False)
            log.info("Exported %-24s %8d rows", table, len(df))
    log.info("Done. Power BI: Get Data -> Excel workbook -> %s", xlsx_path)


if __name__ == "__main__":
    main()
