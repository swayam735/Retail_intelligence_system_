import pytest

pytest.importorskip("fastapi")
pytest.importorskip("httpx")
from fastapi.testclient import TestClient  # noqa: E402


@pytest.fixture(scope="module")
def client(conn):  # `conn` fixture skips if the warehouse is missing
    from api.main import app
    return TestClient(app)


def test_health(client):
    r = client.get("/health")
    assert r.status_code == 200 and r.json()["status"] == "ok"


def test_forecast_days_and_validation(client):
    assert len(client.get("/forecast?days=7").json()) == 7
    assert len(client.get("/forecast?days=5&include_backtest=true").json()) == 65
    assert client.get("/forecast?days=0").status_code == 422
    assert client.get("/forecast?days=91").status_code == 422


def test_customer_lookup(client):
    r = client.get("/customers/1")
    assert r.status_code == 200
    body = r.json()
    assert body["customer_id"] == 1 and 0 <= body["churn_probability"] <= 1
    assert client.get("/customers/99999999").status_code == 404


def test_at_risk_sorted_and_active_only(client):
    rows = client.get("/customers/at-risk?limit=10").json()
    probs = [x["churn_probability"] for x in rows]
    assert probs == sorted(probs, reverse=True)
    assert all(x["already_churned"] == 0 for x in rows)


def test_sql_injection_is_not_possible(client):
    # path param is typed int -> rejected; query params are bound, never string-formatted
    assert client.get("/customers/1;DROP TABLE fact_sales").status_code == 422
    assert client.get("/kpis/monthly?year=2024' OR '1'='1").status_code == 422
    assert client.get("/health").status_code == 200


def test_kpis_and_segments_and_metrics(client):
    assert len(client.get("/kpis/monthly?year=2024").json()) == 12
    assert len(client.get("/segments/summary").json()) >= 3
    assert any(m["metric"] == "mape_pct" for m in client.get("/metrics").json())
