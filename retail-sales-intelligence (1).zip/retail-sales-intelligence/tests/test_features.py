"""Pure unit tests (no warehouse needed): feature logic must never peek at the future."""
import numpy as np
import pandas as pd
import pytest

import train_forecast as tf


@pytest.fixture
def series():
    idx = pd.date_range("2023-01-01", periods=120, freq="D")
    rng = np.random.default_rng(0)
    return pd.Series(100 + rng.normal(0, 5, 120), index=idx)


def test_feature_row_uses_correct_lags():
    h = np.arange(1.0, 41.0)          # 1..40, most recent value = 40
    row = tf.feature_row(h, pd.Timestamp("2024-03-15"))
    assert row["lag_1"] == 40 and row["lag_7"] == 34 and row["lag_28"] == 13
    assert row["ma7"] == pytest.approx(h[-7:].mean())
    assert row["same_dow_mean_4w"] == pytest.approx(np.mean([34, 27, 20, 13]))


def test_features_do_not_leak_the_future(series):
    """Changing values AFTER day t must not change the features built for day t."""
    t = 70
    X1, _ = tf.build_dataset(series)
    altered = series.copy()
    altered.iloc[t + 1:] = 999_999.0
    X2, _ = tf.build_dataset(altered)
    row_pos = t - tf.MIN_HISTORY
    pd.testing.assert_series_equal(X1.iloc[row_pos], X2.iloc[row_pos])


def test_dataset_alignment(series):
    X, y = tf.build_dataset(series)
    assert len(X) == len(y) == len(series) - tf.MIN_HISTORY
    assert X.index.equals(y.index)
    assert X.iloc[0]["lag_1"] == series.iloc[tf.MIN_HISTORY - 1]  # features come from the day BEFORE the target


def test_mape_and_mae():
    assert tf.mape([100, 200], [110, 180]) == pytest.approx(10.0)
    assert tf.mae([100, 200], [110, 180]) == pytest.approx(15.0)


def test_weekday_baseline_repeats_weekly(series):
    b = tf.weekday_baseline(series, 14)
    assert b.iloc[0] == pytest.approx(b.iloc[7]) and len(b) == 14
