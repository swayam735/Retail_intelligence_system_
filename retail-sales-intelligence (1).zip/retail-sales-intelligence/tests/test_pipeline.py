"""
Data-integrity + model-quality tests.
Run `python run_pipeline.py` once, then:   python -m pytest -q
"""


# ----------------------------- warehouse integrity ---------------------------
def test_all_tables_and_views_exist(conn):
    names = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type IN ('table','view')")}
    expected = {
        "fact_sales", "dim_date", "dim_customer", "dim_product", "dim_store",
        "ml_sales_forecast", "ml_customer_churn", "ml_customer_segments", "ml_model_metrics",
        "vw_monthly_kpi_summary", "vw_daily_sales", "vw_product_performance", "vw_customer_360",
    }
    assert expected <= names, f"missing: {expected - names}"


def test_no_invalid_rows_in_fact(conn):
    assert conn.execute("SELECT COUNT(*) FROM fact_sales WHERE quantity <= 0").fetchone()[0] == 0
    assert conn.execute("SELECT COUNT(*) FROM fact_sales WHERE sales_amount IS NULL").fetchone()[0] == 0
    assert conn.execute("SELECT COUNT(*) - COUNT(DISTINCT order_id) FROM fact_sales").fetchone()[0] == 0


def test_dimension_keys_unique(conn):
    for table, col in [("dim_customer", "customer_id"), ("dim_product", "product_id"), ("dim_store", "store_id")]:
        total, distinct = conn.execute(f"SELECT COUNT(*), COUNT(DISTINCT {col}) FROM {table}").fetchone()
        assert total == distinct, table


def test_referential_integrity(conn):
    for dim, key in [("dim_customer", "customer_key"), ("dim_product", "product_key"),
                     ("dim_store", "store_key"), ("dim_date", "date_key")]:
        orphans = conn.execute(
            f"SELECT COUNT(*) FROM fact_sales f LEFT JOIN {dim} d ON f.{key} = d.{key} WHERE d.{key} IS NULL"
        ).fetchone()[0]
        assert orphans == 0, f"orphan rows for {dim}"


def test_sales_amount_matches_price_times_quantity(conn):
    bad = conn.execute(
        "SELECT COUNT(*) FROM fact_sales "
        "WHERE ABS(sales_amount - quantity * unit_price * (1 - discount_pct)) > 0.05"
    ).fetchone()[0]
    assert bad == 0


# ----------------------------- ML output contracts ---------------------------
def test_forecast_table_contract(conn):
    import pandas as pd
    df = pd.read_sql("SELECT * FROM ml_sales_forecast", conn)
    fut, bt = df[df.record_type == "forecast"], df[df.record_type == "backtest"]
    last_sale = conn.execute("SELECT MAX(sales_date) FROM vw_daily_sales").fetchone()[0][:10]
    assert len(fut) == 90 and len(bt) == 60
    assert fut.forecast_date.min() > last_sale, "future forecast must start AFTER the last actual day"
    assert (df.predicted_sales >= 0).all()
    assert (df.lower_bound <= df.predicted_sales).all() and (df.predicted_sales <= df.upper_bound).all()
    assert bt.actual_sales.notna().all() and fut.actual_sales.isna().all()


def test_churn_table_contract(conn):
    import pandas as pd
    df = pd.read_sql("SELECT * FROM ml_customer_churn", conn)
    assert df.customer_id.is_unique
    assert df.churn_probability.between(0, 1).all()
    assert set(df.churn_risk_band) <= {"Low", "Medium", "High"}
    assert set(df.already_churned) <= {0, 1}


def test_every_customer_has_exactly_one_segment(conn):
    n_seg, n_distinct = conn.execute("SELECT COUNT(*), COUNT(DISTINCT customer_id) FROM ml_customer_segments").fetchone()
    assert n_seg == n_distinct > 0
    assert conn.execute("SELECT COUNT(*) FROM ml_customer_segments WHERE rfm_segment IS NULL").fetchone()[0] == 0


# ----------------------------- model QUALITY GATES ---------------------------
def _mape(metrics, model, note_prefix):
    sel = metrics[(metrics.task == "forecast") & (metrics.model == model) & (metrics.metric == "mape_pct")
                  & metrics.note.str.startswith(note_prefix)]
    return float(sel.value.iloc[0])


def test_forecast_beats_every_baseline_one_step(metrics):
    final = _mape(metrics, "blend (final)", "one-step")
    for baseline in ["naive (yesterday)", "seasonal_naive (last week)", "moving_avg_7d", "same_weekday_4w_avg"]:
        assert final < _mape(metrics, baseline, "one-step"), f"model does not beat {baseline}"


def test_forecast_beats_baseline_multi_step(metrics):
    assert _mape(metrics, "blend (final)", "recursive") < _mape(metrics, "same_weekday_4w_avg", "recursive")


def test_forecast_error_is_reasonable(metrics):
    assert _mape(metrics, "blend (final)", "one-step") < 15.0


def test_churn_model_discriminates(metrics):
    auc = float(metrics[(metrics.task == "churn") & (metrics.model == "xgboost") & (metrics.metric == "auc")].value.iloc[0])
    assert auc >= 0.85
