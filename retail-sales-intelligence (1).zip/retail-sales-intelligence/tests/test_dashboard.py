from pathlib import Path

import pytest

pytest.importorskip("streamlit")
from streamlit.testing.v1 import AppTest  # noqa: E402

APP = str(Path(__file__).resolve().parents[1] / "dashboard" / "app.py")


def test_dashboard_renders_without_errors(conn):
    at = AppTest.from_file(APP, default_timeout=90).run()
    assert not at.exception
    assert [t.label for t in at.tabs] == ["Overview", "Sales forecast", "Customers", "Products", "Model quality"]
    assert len(at.metric) >= 4


def test_year_filter_changes_numbers(conn):
    at = AppTest.from_file(APP, default_timeout=90).run()
    latest_year_revenue = at.metric[0].value          # sidebar defaults to the latest year
    at.sidebar.selectbox[0].select("All years").run()
    assert not at.exception
    assert at.metric[0].value != latest_year_revenue  # all-years revenue must differ from a single year
