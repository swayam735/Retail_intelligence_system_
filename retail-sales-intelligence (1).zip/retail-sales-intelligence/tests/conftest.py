import sqlite3
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
for p in (ROOT, ROOT / "python", ROOT / "python" / "forecasting"):
    sys.path.insert(0, str(p))

DB_PATH = ROOT / "data" / "warehouse.db"


@pytest.fixture(scope="session")
def conn():
    if not DB_PATH.exists():
        pytest.skip("warehouse.db not found - run `python run_pipeline.py` first")
    connection = sqlite3.connect(DB_PATH)
    yield connection
    connection.close()


@pytest.fixture(scope="session")
def metrics(conn):
    import pandas as pd
    return pd.read_sql("SELECT * FROM ml_model_metrics", conn)
