"""
REST API for the Retail Sales Intelligence System.

Run:   uvicorn api.main:app --reload
Docs:  http://127.0.0.1:8000/docs   (interactive Swagger UI, auto-generated)

All data comes from the SQL warehouse via python/db_connector.py, so the API
always serves the latest pipeline output - it never trains anything itself.
"""

import sys
from pathlib import Path
from typing import Optional

import pandas as pd
from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel

sys.path.append(str(Path(__file__).resolve().parents[1] / "python"))
from db_connector import DB_PATH, read_query  # noqa: E402

app = FastAPI(
    title="Retail Sales Intelligence API",
    description="Serves sales forecasts, churn risk, customer segments and KPIs from the SQL warehouse.",
    version="1.0.0",
)


@app.exception_handler(FileNotFoundError)
async def warehouse_missing(_: Request, exc: FileNotFoundError):
    return JSONResponse(status_code=503, content={"detail": str(exc)})


# ----------------------------------------------------------------------------
# Response models
# ----------------------------------------------------------------------------
class ForecastPoint(BaseModel):
    forecast_date: str
    predicted_sales: float
    lower_bound: Optional[float] = None
    upper_bound: Optional[float] = None
    actual_sales: Optional[float] = None
    record_type: str


class CustomerProfile(BaseModel):
    customer_id: int
    customer_name: Optional[str] = None
    region: Optional[str] = None
    age_band: Optional[str] = None
    churn_probability: Optional[float] = None
    churn_risk_band: Optional[str] = None
    already_churned: Optional[int] = None
    rfm_segment: Optional[str] = None
    recency_days: Optional[int] = None
    frequency: Optional[int] = None
    monetary: Optional[float] = None


class MonthlyKpi(BaseModel):
    year_month: str
    orders: int
    revenue: float
    avg_order_value: float
    promo_revenue: float


class SegmentSummary(BaseModel):
    rfm_segment: str
    customers: int
    avg_monetary: float


def _records(df: pd.DataFrame) -> list[dict]:
    """DataFrame -> JSON-safe list of dicts (NaN -> None)."""
    return df.astype(object).where(df.notna(), None).to_dict("records")


# ----------------------------------------------------------------------------
# Endpoints
# ----------------------------------------------------------------------------
@app.get("/health", tags=["system"])
def health():
    """Liveness + data-freshness check (use it for container health checks)."""
    tables = read_query("SELECT name FROM sqlite_master WHERE type IN ('table','view')")["name"].tolist()
    latest = read_query("SELECT MAX(sales_date) AS d FROM vw_daily_sales")["d"].iloc[0]
    return {"status": "ok", "warehouse": str(DB_PATH.name), "tables": len(tables), "latest_sales_date": latest}


@app.get("/forecast", response_model=list[ForecastPoint], tags=["forecast"])
def forecast(
    days: int = Query(30, ge=1, le=90, description="How many future days to return"),
    include_backtest: bool = Query(False, description="Also return the 60-day backtest rows (with actuals)"),
):
    """Daily sales forecast with an approximate 80% prediction interval."""
    df = read_query(
        "SELECT forecast_date, predicted_sales, lower_bound, upper_bound, actual_sales, record_type "
        "FROM ml_sales_forecast ORDER BY forecast_date"
    )
    future = df[df["record_type"] == "forecast"].head(days)
    out = pd.concat([df[df["record_type"] == "backtest"], future]) if include_backtest else future
    return _records(out)


@app.get("/customers/at-risk", response_model=list[CustomerProfile], tags=["customers"])
def at_risk_customers(limit: int = Query(20, ge=1, le=200)):
    """Still-active customers with the highest churn probability: the retention call list."""
    df = read_query(
        "SELECT * FROM vw_customer_360 WHERE already_churned = 0 "
        "ORDER BY churn_probability DESC LIMIT ?",
        params=(limit,),
    )
    return _records(df)


@app.get("/customers/{customer_id}", response_model=CustomerProfile, tags=["customers"])
def customer(customer_id: int):
    """Churn risk + RFM segment for one customer."""
    df = read_query("SELECT * FROM vw_customer_360 WHERE customer_id = ?", params=(customer_id,))
    if df.empty:
        raise HTTPException(status_code=404, detail=f"Customer {customer_id} not found")
    return _records(df)[0]


@app.get("/kpis/monthly", response_model=list[MonthlyKpi], tags=["kpis"])
def monthly_kpis(year: Optional[int] = Query(None, ge=2000, le=2100)):
    """Monthly revenue / orders / AOV, optionally filtered to one year."""
    if year is None:
        df = read_query("SELECT year_month, orders, revenue, avg_order_value, promo_revenue "
                        "FROM vw_monthly_kpi_summary ORDER BY year_month")
    else:
        df = read_query("SELECT year_month, orders, revenue, avg_order_value, promo_revenue "
                        "FROM vw_monthly_kpi_summary WHERE year = ? ORDER BY year_month", params=(year,))
    return _records(df)


@app.get("/segments/summary", response_model=list[SegmentSummary], tags=["customers"])
def segment_summary():
    df = read_query(
        "SELECT rfm_segment, COUNT(*) AS customers, ROUND(AVG(monetary), 2) AS avg_monetary "
        "FROM ml_customer_segments GROUP BY rfm_segment ORDER BY customers DESC"
    )
    return _records(df)


@app.get("/metrics", tags=["system"])
def model_metrics():
    """Latest model evaluation metrics (same numbers the pipeline printed)."""
    return _records(read_query("SELECT task, model, metric, value, note, run_at FROM ml_model_metrics"))
