# 📘 Step-by-Step Guide (Hinglish)

Is guide me sab kuch hai: install → run → Power BI → GitHub → interview → resume.
**Order me chalo, kuch skip mat karo.**

---

## 0. Ye project kya karta hai (30 second me)

Ek retail company ka sales data hai (synthetic, matlab nakli lekin realistic).
Project:
1. Data ko **SQL warehouse** me daalta hai (star schema) aur clean karta hai
2. **3 ML models** chalata hai: sales forecast (agle 90 din), customer churn, customer segments
3. Result **dashboard, API aur Power BI** me dikhata hai

Tumhe sirf: **setup → `run_pipeline.py` → Power BI me dashboard banana** karna hai. Baaki sab ready hai.

---

## 1. Pehle ye install karo (sirf ek baar)

| Cheez | Kahan se | Note |
|---|---|---|
| **Python 3.11 ya 3.12** | python.org/downloads | Windows pe installer me **"Add Python to PATH" ✔ zaroor tick karo** |
| **VS Code** | code.visualstudio.com | Code padhne/edit karne ke liye |
| **Git** | git-scm.com | GitHub pe daalne ke liye |
| **Power BI Desktop** | Microsoft Store (free) | Sirf Windows pe chalta hai |

Check karo: Command Prompt kholo aur likho `python --version`. Version dikhna chahiye.

---

## 2. Project setup + run

### Windows (sabse easy)
1. Zip extract karo → folder `retail-sales-intelligence` banega
2. Folder kholo, upar address bar me `cmd` likho, Enter dabao (terminal usi folder me khulega)
3. Ye likho:
   ```
   setup.bat
   ```
   (2-5 minute lagte hain, packages download hote hain)
4. Fir:
   ```
   run_all.bat
   ```
   Ye pipeline chalayega (~1-2 min) aur phir tests.

**Agar `.bat` na chale, manual commands:**
```
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python run_pipeline.py
python -m pytest -q
```

### Mac / Linux
```
make setup
source .venv/bin/activate
make run
make test
```

### Run karne pe kya dikhega
Pipeline 7 steps chalata hai:

| Step | Kya hota hai |
|---|---|
| 1 | Synthetic data banta hai (customers, products, stores, ~78K sales) |
| 2 | SQL warehouse banta hai, data clean hota hai (duplicates, galat rows hat jaate hain) |
| 3 | SQL views banti hain |
| 4 | Forecast model train hota hai (**30-60 sec lagta hai, hang nahi hua hai**) |
| 5 | Churn model |
| 6 | Customer segmentation |
| 7 | Power BI ke liye Excel file export |

End me **RESULTS SUMMARY** aayega. Mere run me ye aaya tha (tumhare me thoda alag ho sakta hai):

```
naive (yesterday)               18.45%
7-day moving average            12.84%
same_weekday_4w_avg             11.95%
blend (final)                    9.69%   <- tumhara model
-> improvement vs naive: 47.5% | vs best baseline: 19.0%
```
Aur tests: **25 passed** aana chahiye.

Jo files bani: `data/warehouse.db` (database) aur `powerbi/exports/retail_powerbi_data.xlsx` (Power BI ke liye).

---

## 3. Dashboard aur API dekho (demo ke liye)

**Dashboard** (Power BI ke bina bhi live demo):
```
streamlit run dashboard/app.py
```
Browser me `http://localhost:8501` khulega. 5 tabs hain: Overview, Sales forecast, Customers, Products, Model quality.

**API:**
```
uvicorn api.main:app --reload
```
Browser me `http://127.0.0.1:8000/docs` kholo. Waha "Try it out" se `/forecast?days=7` try karo.

Band karne ke liye terminal me `Ctrl + C`.
Windows shortcut: `start_dashboard.bat` aur `start_api.bat`.

---

## 4. Power BI me dashboard banao (step by step)

> Ye wo ek kaam hai jo main nahi kar sakta, kyunki `.pbix` file sirf Power BI Desktop banata hai. Lekin 30-45 min me ho jaata hai.

### 4.1 Data load karo
1. Power BI Desktop kholo → **Get data → Excel workbook**
2. File chuno: `powerbi/exports/retail_powerbi_data.xlsx`
3. Navigator me upar **"Select multiple items"** pe tick karo, phir **saari 13 sheets** pe tick lagao → **Load**

### 4.2 Relationships banao (zaroori!)
Left side me **Model view** (teesra icon) kholo. Ye 4 relationships banao (column ko drag karke dusri table ke column pe chhodo):

| fact_sales ka column | → Is table ka column |
|---|---|
| `date_key` | `dim_date[date_key]` |
| `customer_key` | `dim_customer[customer_key]` |
| `product_key` | `dim_product[product_key]` |
| `store_key` | `dim_store[store_key]` |

Har ek **Many-to-one**, direction **Single** hona chahiye (dim → fact). Baaki tables (`vw_*`, `ml_*`) ko kisi se jodna **nahi** hai.

### 4.3 Date table mark karo
`dim_date` select karo → upar **Table tools → Mark as date table** → column `full_date` chuno → OK.
(Isse YoY, YTD wale measures kaam karte hain.)

### 4.4 Measures daalo
1. `powerbi/measures.dax` file kholo (VS Code me)
2. Power BI me **Home → Enter data** → table ka naam `_Measures` → Load (ek khali table banega measures rakhne ke liye)
3. Ab har measure ke liye: **right-click `_Measures` → New measure** → file se ek measure copy-paste → Enter
4. Pehle ye 5 daalo (kaafi hain shuru ke liye): `Total Revenue`, `Total Orders`, `Average Order Value`, `Revenue PY`, `YoY Growth %`. Baaki baad me.

### 4.5 Pages aur visuals
Page 1, 2, 3 ... bana ke ye visuals lagao (poori list `powerbi/POWERBI_GUIDE.md` me hai):

| Page | Visuals |
|---|---|
| **Executive Overview** | 4 Cards (Total Revenue, Orders, AOV, YoY Growth %), Line chart (month × revenue), Bar chart (region × revenue), Slicer (year) |
| **Sales Forecast** | Line chart: X-axis = `ml_sales_forecast[forecast_date]`, Values = Backtest Actual, Forecast Predicted, Forecast Lower, Forecast Upper. Cards: Forecast Next 30 Days |
| **Customers** | Bar chart (`rfm_segment` × Customers), Column chart (`churn_risk_band`), Table (top churn probability, filter `already_churned = 0`) |
| **Model Quality** | `ml_model_metrics` ka table, Cards: Forecast MAPE %, Naive Baseline MAPE % |

### 4.6 Save aur record
- **File → Save as** → `retail_sales_intelligence.pbix` (project folder me `powerbi/` me rakho)
- Screen recording (Windows: `Win + G`) → 60 sec ka video/GIF → README me upar laga do. Recruiter `.pbix` kholte nahi, video dekhte hain.

---

## 5. GitHub pe daalo

1. github.com pe naya repository banao: `retail-sales-intelligence` (Public)
2. Project folder ke terminal me:
```
git init
git add .
git commit -m "Retail Sales Intelligence: SQL + ML + API + dashboard"
git branch -M main
git remote add origin https://github.com/TUMHARA-USERNAME/retail-sales-intelligence.git
git push -u origin main
```
3. GitHub pe **Actions** tab me CI chalega (pipeline + tests). Green tick = ✅ screenshot le lo.
4. README me dashboard ka screenshot/GIF add karo.

---

## 6. Code ko samjho (interview se pehle ye zaroor karo)

Is order me padho, har file 10-15 min:
1. `python/db_connector.py` (chhota, simple)
2. `data/generate_data.py` (data kaise bana)
3. `sql/etl/load_data.py` (cleaning kaise hui)
4. `sql/schema/create_schema.sql` + `sql/analytics/queries.sql` (**SQL interview ke liye sabse important**)
5. `python/forecasting/train_forecast.py` (sabse bada, `feature_row()` aur `BlendForecaster` pe focus)
6. `python/churn_model/train_churn.py`
7. `tests/` (kaise quality check hoti hai)

> ⚠️ Jo cheez samajh na aaye wo interview me mat bolo. Jo tum samjha sako, wahi tumhari hai.

---

## 7. Interview me kaise explain karo

**60-second pitch:**
> "Maine ek end-to-end retail analytics system banaya. Raw data ko SQL star-schema warehouse me clean karke load kiya, phir 3 ML models banaye: sales forecast, churn aur customer segmentation. Predictions wapas SQL me likhi, taaki Power BI, ek REST API aur ek dashboard teeno same data use karein. Forecast me maine 4 baselines ke against test kiya; final model naive se 47% aur sabse strong baseline se 19% behtar raha, 60 din ke holdout pe MAPE 9.7%. Poora pipeline ek command me chalta hai aur 25 automated tests CI me chalte hain."

**Jo sawal pakka aayenge:**

| Sawal | Jawab |
|---|---|
| Star schema kyun? | Fact table me measures, dimensions me descriptions. Queries fast aur BI tools ke liye natural. |
| Data leakage kaise roka? | Forecast me ek hi `feature_row()` function training aur forecasting dono ke liye, sirf pichhle din tak ka data use karta hai, aur test hai jo prove karta hai ki future badalne se features nahi badalte. Churn me snapshot approach: features T-90 din tak, label agle 90 din ka. |
| Accuracy kitni hai? | Test window pe MAPE 9.69%. Naive 18.45%, best baseline 11.95%. Multi-step (60 din ek saath) me 11.97% vs 16.01%. |
| Blend kyun, sirf XGBoost kyun nahi? | Maine dekha ki raw XGBoost moving-average se bhi kharab tha (13.6%). Target ko ratio (sales / 7-day avg) banane se 10.4% hua. Ridge 10.8%. Dono ko blend karke 9.69%. Blend weight validation window pe choose kiya, test pe nahi. |
| **Churn model kaisa hai?** (honest jawab) | "AUC 0.95, lekin maine ek recency-only baseline bhi check kiya jo 0.95 deta hai, to model usse behtar nahi hai is synthetic data pe. Dominant signal recency hai. Active customers pe AUC 0.70 hai. Real data me order frequency decay aur seasonality se lift milna chahiye, lekin is data pe main wo claim nahi karunga." (Ye jawab interviewer ko impress karta hai.) |
| Production-ready kaise? | Tests + quality gates, CI, logging, parameterized SQL, config via env var, Docker, ek command me rebuild, API health check. |
| Real data pe kya badlega? | `db_connector.py` ko SQL Server/Postgres pe point karo, CSVs badlo, holiday/promo calendar features add karo, model retraining schedule (Airflow/cron) lagao. |
| Data synthetic kyun? | Reproducibility, aur dirty data inject kar sakta tha cleaning dikhane ke liye. Resume me bhi likha hai ki synthetic hai. |

---

## 8. Resume me kya likho

**Project title:** Retail Sales Intelligence System | Python, SQL, XGBoost, FastAPI, Streamlit, Power BI, Docker, GitHub Actions

- Designed a **SQL star-schema warehouse** (fact + 4 dimensions, window-function analytics, reusable views) with an ETL layer that cleans and validates 78K+ transactions from a synthetic retail dataset
- Built a **90-day sales forecasting model** (tuned XGBoost + Ridge blend, time-series CV): **9.7% MAPE vs 18.5% naive baseline (47% lower error) and 12.0% for the strongest baseline**; validated on an untouched 60-day holdout and a multi-step backtest
- Developed a **leakage-safe customer churn model** using snapshot training, evaluated with 5-fold CV (AUC 0.95) and benchmarked against a recency-only baseline
- Segmented customers with **RFM + K-Means** into 6 actionable groups; wrote all predictions back to SQL for BI consumption
- Delivered results via **Power BI dashboard (DAX)**, a **FastAPI** service and a **Streamlit** app, all reading the same SQL views
- Added **25 automated tests** (data integrity, leakage, API, model-quality gates) with **GitHub Actions CI** and Docker

> Resume me "AUC 0.95" likho to interview me recency baseline wali baat batane ke liye taiyaar raho (section 7).

**Keywords (ATS):** SQL, Star Schema, ETL, Window Functions, Python, Pandas, Scikit-learn, XGBoost, Time Series Forecasting, Feature Engineering, K-Means, RFM, Power BI, DAX, FastAPI, Streamlit, Docker, CI/CD, GitHub Actions, pytest, Data Warehousing, Churn Prediction, Demand Forecasting

---

## 9. Common errors aur fix

| Error | Fix |
|---|---|
| `'python' is not recognized` | Python reinstall karo, **"Add to PATH" tick karo**. Ya `py` try karo: `py -m venv .venv` |
| `pip install` fail / xgboost error | `python -m pip install --upgrade pip`. Python 3.11 ya 3.12 use karo (bahut naya ya purana version issue karta hai) |
| `Warehouse not found` | Pehle `python run_pipeline.py` chalao |
| Tests "skipped" | Pipeline nahi chali, pehle run karo |
| Port already in use | `streamlit run dashboard/app.py --server.port 8502` ya `uvicorn api.main:app --port 8001` |
| `.venv\Scripts\activate` blocked (PowerShell) | `Set-ExecutionPolicy -Scope Process Bypass` phir dobara. Ya Command Prompt (cmd) use karo |
| Power BI me date hierarchy dikh rahi | Visual me field ke saamne dropdown → "Date" chuno (Date Hierarchy nahi) |
| Power BI measure error | Relationships (4.2) aur Mark as date table (4.3) check karo |
| Pipeline bahut slow | Forecast tuning 30-60 sec leta hai, normal hai. Slow laptop pe 2 min tak |

---

## 10. Apna real data lagana (optional)

`data/raw/` me 4 CSV daalo (same column names):

| File | Columns |
|---|---|
| `customers.csv` | customer_id, customer_name, signup_date, region, age |
| `products.csv` | product_id, product_name, category, unit_cost, unit_price |
| `stores.csv` | store_id, store_name, region, city |
| `sales.csv` | order_id, order_date, customer_id, product_id, store_id, quantity, promo_flag, unit_price, discount_pct, sales_amount |

Fir: `python run_pipeline.py --skip-generate`
Forecast ke liye kam se kam ~200 din ka daily data chahiye.

---

## 11. Cheat-sheet

```
python run_pipeline.py            # sab kuch banao
python run_pipeline.py --skip-generate   # apna data use karo
python -m pytest -q               # tests
streamlit run dashboard/app.py    # dashboard
uvicorn api.main:app --reload     # API (/docs)
```
