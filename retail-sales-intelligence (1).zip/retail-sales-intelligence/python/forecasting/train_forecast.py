"""
train_forecast.py
------------------
Forecasts total daily sales for the next 90 days.

Model
    A blend of two regressors trained on a *relative* target
    (sales / trailing-7-day mean):
        1. XGBoost  - hyper-parameters tuned with TimeSeriesSplit CV
        2. Ridge    - linear model, captures smooth weekly/yearly seasonality
    The blend weight is chosen on a validation window; the final test
    window is never used for any selection (no leakage).

Evaluation (all numbers are saved to the ml_model_metrics table)
    * One-step-ahead MAPE on a 60-day holdout vs. 4 baselines
        naive (yesterday), seasonal-naive (same day last week),
        7-day moving average, same-weekday 4-week average
    * Recursive 60-day-ahead MAPE (the realistic multi-step setting that the
      90-day forecast actually uses) vs. a same-weekday baseline

Output
    ml_sales_forecast  : backtest rows (with actuals) + 90 future rows,
                         with an approximate 80% prediction interval.
"""

import logging
import sys
import warnings
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import xgboost as xgb
from sklearn.linear_model import RidgeCV
from sklearn.model_selection import RandomizedSearchCV, TimeSeriesSplit
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

sys.path.append(str(Path(__file__).resolve().parents[1]))
from db_connector import read_query, save_metrics, write_table  # noqa: E402

warnings.filterwarnings("ignore", category=UserWarning)
logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")
log = logging.getLogger("forecast")

SEED = 42
FORECAST_HORIZON = 90
TEST_DAYS = 60
VAL_DAYS = 60
LAGS = list(range(1, 15)) + [21, 28]
MIN_HISTORY = 30
RIDGE_EXCLUDE = {"dow", "month", "doy"}  # raw calendar ints: useful for trees, not for a linear model
Z_80 = 1.2816  # z-score for an 80% two-sided interval


# ----------------------------------------------------------------------------
# Data + features
# ----------------------------------------------------------------------------
def load_daily_sales() -> pd.Series:
    df = read_query(
        """
        SELECT d.full_date AS order_date, SUM(f.sales_amount) AS total_sales
        FROM fact_sales f JOIN dim_date d ON f.date_key = d.date_key
        GROUP BY d.full_date ORDER BY d.full_date
        """
    )
    df["order_date"] = pd.to_datetime(df["order_date"])
    return df.set_index("order_date").asfreq("D").fillna(0.0)["total_sales"]


def feature_row(h: np.ndarray, date: pd.Timestamp) -> dict:
    """
    Features for predicting `date`, given h = all values strictly BEFORE `date`.
    The same function builds training rows and recursive-forecast rows, so
    there is no train/serve skew.
    """
    r = {f"lag_{k}": h[-k] for k in LAGS}
    r["ma7"] = h[-7:].mean()
    r["ma14"] = h[-14:].mean()
    r["ma30"] = h[-30:].mean()
    r["std7"] = h[-7:].std(ddof=1)
    r["same_dow_mean_4w"] = np.mean([h[-7], h[-14], h[-21], h[-28]])
    r["dow"] = date.dayofweek
    r["month"] = date.month
    r["doy"] = date.dayofyear
    r["is_weekend"] = int(date.dayofweek >= 5)
    for k in range(7):
        r[f"dow_{k}"] = int(date.dayofweek == k)
    angle = 2 * np.pi * date.dayofyear / 365.25
    r["doy_sin"] = np.sin(angle)
    r["doy_cos"] = np.cos(angle)
    return r


def build_dataset(series: pd.Series) -> tuple[pd.DataFrame, pd.Series]:
    vals, dates = series.values, series.index
    rows = [feature_row(vals[:i], dates[i]) for i in range(MIN_HISTORY, len(vals))]
    X = pd.DataFrame(rows, index=dates[MIN_HISTORY:])
    y = pd.Series(vals[MIN_HISTORY:], index=dates[MIN_HISTORY:], name="total_sales")
    return X, y


# ----------------------------------------------------------------------------
# Model
# ----------------------------------------------------------------------------
def tune_xgb(X: pd.DataFrame, ratio_target: pd.Series) -> dict:
    """Randomised search with time-ordered CV (no shuffling, no future leakage)."""
    param_dist = {
        "n_estimators": [200, 300, 400, 600],
        "max_depth": [2, 3, 4, 5],
        "learning_rate": [0.01, 0.02, 0.03, 0.05],
        "subsample": [0.7, 0.8, 1.0],
        "colsample_bytree": [0.6, 0.8, 1.0],
        "min_child_weight": [1, 3, 5, 10],
        "reg_lambda": [1, 2, 5],
    }
    search = RandomizedSearchCV(
        xgb.XGBRegressor(random_state=SEED, n_jobs=1),
        param_dist,
        n_iter=25,
        cv=TimeSeriesSplit(n_splits=4),
        scoring="neg_mean_absolute_percentage_error",
        random_state=SEED,
        n_jobs=-1,
    )
    search.fit(X, ratio_target)
    log.info("Best XGB params: %s (CV MAPE=%.2f%%)", search.best_params_, -search.best_score_ * 100)
    return search.best_params_


class BlendForecaster:
    """XGBoost + Ridge, both predicting sales / ma7, blended with weight w on XGBoost."""

    def __init__(self, xgb_params: dict):
        self.xgb_params = xgb_params

    def fit(self, X: pd.DataFrame, y: pd.Series) -> "BlendForecaster":
        ratio = y / X["ma7"].clip(lower=1.0)
        self.xgb_ = xgb.XGBRegressor(**self.xgb_params, random_state=SEED, n_jobs=-1).fit(X, ratio)
        self.ridge_cols_ = [c for c in X.columns if c not in RIDGE_EXCLUDE]
        self.ridge_ = make_pipeline(StandardScaler(), RidgeCV(alphas=np.logspace(-2, 3, 20)))
        self.ridge_.fit(X[self.ridge_cols_], ratio)
        return self

    def components(self, X: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
        scale = X["ma7"].clip(lower=1.0).values
        return (
            self.xgb_.predict(X) * scale,
            self.ridge_.predict(X[self.ridge_cols_]) * scale,
        )

    def predict(self, X: pd.DataFrame, w: float) -> np.ndarray:
        px, pr = self.components(X)
        return np.maximum(0.0, w * px + (1 - w) * pr)


# ----------------------------------------------------------------------------
# Forecasting + metrics
# ----------------------------------------------------------------------------
def mape(y_true, y_pred) -> float:
    y_true, y_pred = np.asarray(y_true, float), np.asarray(y_pred, float)
    return float(np.mean(np.abs(y_true - y_pred) / np.maximum(np.abs(y_true), 1e-9)) * 100)


def mae(y_true, y_pred) -> float:
    return float(np.mean(np.abs(np.asarray(y_true, float) - np.asarray(y_pred, float))))


def recursive_forecast(model: BlendForecaster, history: pd.Series, horizon: int, w: float) -> pd.Series:
    """Multi-step forecast: each prediction is fed back in as the newest 'actual'."""
    vals = list(history.values)
    dates = pd.date_range(history.index[-1] + pd.Timedelta(days=1), periods=horizon, freq="D")
    preds = []
    for d in dates:
        X = pd.DataFrame([feature_row(np.asarray(vals), d)])
        p = float(model.predict(X, w)[0])
        preds.append(p)
        vals.append(p)
    return pd.Series(preds, index=dates, name="predicted_sales")


def weekday_baseline(history: pd.Series, horizon: int) -> pd.Series:
    """Multi-step baseline: for each future day, mean of that weekday over the last 4 weeks."""
    last4 = history.iloc[-28:]
    by_dow = last4.groupby(last4.index.dayofweek).mean()
    dates = pd.date_range(history.index[-1] + pd.Timedelta(days=1), periods=horizon, freq="D")
    return pd.Series([by_dow[d.dayofweek] for d in dates], index=dates)


def main() -> None:
    log.info("Loading daily sales from warehouse...")
    series = load_daily_sales()
    X, y = build_dataset(series)

    dev_X, dev_y = X.iloc[:-TEST_DAYS], y.iloc[:-TEST_DAYS]
    test_X, test_y = X.iloc[-TEST_DAYS:], y.iloc[-TEST_DAYS:]

    # 1) Tune XGBoost (time-ordered CV on development data only)
    log.info("Tuning XGBoost with TimeSeriesSplit CV...")
    best_params = tune_xgb(dev_X, dev_y / dev_X["ma7"].clip(lower=1.0))

    # 2) Pick blend weight on a validation window (test window untouched)
    tr_X, tr_y = dev_X.iloc[:-VAL_DAYS], dev_y.iloc[:-VAL_DAYS]
    val_X, val_y = dev_X.iloc[-VAL_DAYS:], dev_y.iloc[-VAL_DAYS:]
    m_val = BlendForecaster(best_params).fit(tr_X, tr_y)
    vx, vr = m_val.components(val_X)
    weights = np.linspace(0, 1, 11)
    best_w = float(min(weights, key=lambda w: mape(val_y, w * vx + (1 - w) * vr)))
    log.info("Blend weight on XGBoost chosen on validation window: %.1f (Ridge: %.1f)", best_w, 1 - best_w)

    # 3) One-step-ahead evaluation on the untouched test window
    m_dev = BlendForecaster(best_params).fit(dev_X, dev_y)
    tx, tr_ = m_dev.components(test_X)
    one_step = {
        "naive (yesterday)": test_X["lag_1"].values,
        "seasonal_naive (last week)": test_X["lag_7"].values,
        "moving_avg_7d": test_X["ma7"].values,
        "same_weekday_4w_avg": test_X["same_dow_mean_4w"].values,
        "xgboost_ratio": np.maximum(0, tx),
        "ridge_ratio": np.maximum(0, tr_),
        "blend (final)": np.maximum(0, best_w * tx + (1 - best_w) * tr_),
    }
    metrics = []
    log.info("--- One-step-ahead, %d-day holdout ---", TEST_DAYS)
    for name, pred in one_step.items():
        m, a = mape(test_y, pred), mae(test_y, pred)
        log.info("%-28s MAPE %6.2f%%   MAE %10.0f", name, m, a)
        metrics += [
            {"model": name, "metric": "mape_pct", "value": m, "note": "one-step-ahead, 60-day holdout"},
            {"model": name, "metric": "mae", "value": a, "note": "one-step-ahead, 60-day holdout"},
        ]

    baselines = {k: v for k, v in one_step.items() if k not in ("xgboost_ratio", "ridge_ratio", "blend (final)")}
    blend_mape = mape(test_y, one_step["blend (final)"])
    best_base_name = min(baselines, key=lambda k: mape(test_y, baselines[k]))
    best_base_mape = mape(test_y, baselines[best_base_name])
    naive_mape = mape(test_y, baselines["naive (yesterday)"])
    log.info("Blend improves MAPE by %.1f%% vs naive, %.1f%% vs best baseline (%s)",
             (1 - blend_mape / naive_mape) * 100, (1 - blend_mape / best_base_mape) * 100, best_base_name)

    # 4) Recursive (multi-step) backtest: forecast all 60 test days from the origin
    origin = test_X.index[0] - pd.Timedelta(days=1)
    history = series.loc[:origin]
    rec_pred = recursive_forecast(m_dev, history, TEST_DAYS, best_w)
    rec_base = weekday_baseline(history, TEST_DAYS)
    actual_test = series.loc[rec_pred.index]
    rec_mape, rec_base_mape = mape(actual_test, rec_pred), mape(actual_test, rec_base)
    log.info("--- Recursive %d-day-ahead backtest ---", TEST_DAYS)
    log.info("blend %.2f%%   vs same-weekday baseline %.2f%%", rec_mape, rec_base_mape)
    metrics += [
        {"model": "blend (final)", "metric": "mape_pct", "value": rec_mape, "note": "recursive 60-day-ahead backtest"},
        {"model": "same_weekday_4w_avg", "metric": "mape_pct", "value": rec_base_mape, "note": "recursive 60-day-ahead backtest"},
    ]

    # Interval half-width from the (honest, multi-step) relative residuals
    sigma_rel = float(np.std((actual_test.values - rec_pred.values) / np.maximum(rec_pred.values, 1.0)))
    metrics += [
        {"model": "blend (final)", "metric": "blend_weight_xgboost", "value": best_w, "note": "chosen on validation window"},
        {"model": "blend (final)", "metric": "improvement_vs_naive_pct", "value": (1 - blend_mape / naive_mape) * 100, "note": "one-step-ahead MAPE"},
        {"model": "blend (final)", "metric": "improvement_vs_best_baseline_pct", "value": (1 - blend_mape / best_base_mape) * 100, "note": f"best baseline = {best_base_name}"},
        {"model": "blend (final)", "metric": "interval_rel_sigma", "value": sigma_rel, "note": "80% interval = pred * (1 +/- 1.28 * sigma)"},
    ]

    # 5) Refit on ALL data, forecast the future
    m_full = BlendForecaster(best_params).fit(X, y)
    future = recursive_forecast(m_full, series, FORECAST_HORIZON, best_w)

    model_label = f"blend(xgb={best_w:.1f},ridge={1 - best_w:.1f})"
    generated_at = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")

    def pack(pred: pd.Series, record_type: str, actual: pd.Series | None) -> pd.DataFrame:
        return pd.DataFrame({
            "forecast_date": pred.index.strftime("%Y-%m-%d"),
            "predicted_sales": pred.values.round(2),
            "lower_bound": (pred.values * (1 - Z_80 * sigma_rel)).clip(min=0).round(2),
            "upper_bound": (pred.values * (1 + Z_80 * sigma_rel)).round(2),
            "actual_sales": actual.values.round(2) if actual is not None else np.nan,
            "record_type": record_type,
            "model_name": model_label,
            "generated_at": generated_at,
        })

    out = pd.concat([pack(rec_pred, "backtest", actual_test), pack(future, "forecast", None)], ignore_index=True)
    write_table(out, "ml_sales_forecast", if_exists="replace")
    save_metrics("forecast", metrics)
    log.info("Wrote %d rows to ml_sales_forecast (%d backtest + %d future)", len(out), TEST_DAYS, FORECAST_HORIZON)


if __name__ == "__main__":
    main()
