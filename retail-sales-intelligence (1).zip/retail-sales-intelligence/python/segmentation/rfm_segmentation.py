"""
rfm_segmentation.py
--------------------
Classic Recency-Frequency-Monetary segmentation, refined with K-Means so
segments are data-driven rather than arbitrary quantile cutoffs, then
labeled with business-friendly names (Champions, At Risk, Lost, etc.)

Writes customer_id, recency_days, frequency, monetary, rfm_segment
to ml_customer_segments.
"""

import sys
import logging
from pathlib import Path

import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans

sys.path.append(str(Path(__file__).resolve().parents[1]))
from db_connector import read_query, write_table  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")
log = logging.getLogger("rfm")

N_CLUSTERS = 5


def load_rfm_base() -> pd.DataFrame:
    # Same logic as sql/analytics/queries.sql query #4 - kept in sync deliberately
    query = """
        WITH last_order_date AS (SELECT MAX(full_date) AS max_date FROM dim_date)
        SELECT
            c.customer_id,
            julianday((SELECT max_date FROM last_order_date)) - julianday(MAX(d.full_date)) AS recency_days,
            COUNT(DISTINCT f.order_id) AS frequency,
            SUM(f.sales_amount) AS monetary
        FROM fact_sales f
        JOIN dim_customer c ON f.customer_key = c.customer_key
        JOIN dim_date d ON f.date_key = d.date_key
        GROUP BY c.customer_id
    """
    return read_query(query)


def label_segment(row) -> str:
    """Business-friendly labels layered on top of the K-Means cluster,
    using each cluster's average RFM profile."""
    r, f, m = row["recency_days"], row["frequency"], row["monetary"]
    if r <= 60 and f >= row["freq_p75"] and m >= row["mon_p75"]:
        return "Champions"
    if r <= 90 and f >= row["freq_p50"]:
        return "Loyal Customers"
    if r > 180 and f >= row["freq_p50"]:
        return "At Risk"
    if r > 270:
        return "Lost"
    if f <= row["freq_p25"] and r <= 120:
        return "New / Low Engagement"
    return "Needs Attention"


def main():
    log.info("Loading RFM base table...")
    rfm = load_rfm_base()
    rfm = rfm.dropna(subset=["monetary"])

    # Cluster on standardized RFM (data-driven grouping)
    features = rfm[["recency_days", "frequency", "monetary"]]
    scaled = StandardScaler().fit_transform(features)

    kmeans = KMeans(n_clusters=N_CLUSTERS, random_state=42, n_init=10)
    rfm["cluster"] = kmeans.fit_predict(scaled)

    # Compute percentile thresholds once, used to translate clusters into
    # business-readable labels (Champions / At Risk / Lost / etc.)
    rfm["freq_p75"] = rfm["frequency"].quantile(0.75)
    rfm["freq_p50"] = rfm["frequency"].quantile(0.50)
    rfm["freq_p25"] = rfm["frequency"].quantile(0.25)
    rfm["mon_p75"] = rfm["monetary"].quantile(0.75)

    rfm["rfm_segment"] = rfm.apply(label_segment, axis=1)

    segment_summary = rfm.groupby("rfm_segment").agg(
        customers=("customer_id", "count"),
        avg_recency=("recency_days", "mean"),
        avg_frequency=("frequency", "mean"),
        avg_monetary=("monetary", "mean"),
    ).round(1).sort_values("customers", ascending=False)
    log.info("Segment summary:\n%s", segment_summary.to_string())

    output = rfm[["customer_id", "recency_days", "frequency", "monetary", "rfm_segment"]].copy()
    output["recency_days"] = output["recency_days"].round(0).astype(int)

    write_table(output, "ml_customer_segments", if_exists="replace")
    log.info("Wrote %d customer segments to ml_customer_segments", len(output))


if __name__ == "__main__":
    main()
