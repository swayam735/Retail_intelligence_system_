"""
train_churn.py
---------------
Customer churn model built the way it is done in production: SNAPSHOTS.

    Training snapshot  (as_of = latest_date - 90 days)
        features : behaviour up to `as_of`
        label    : 1 if the customer placed NO order in the following 90 days
    Scoring snapshot   (as_of = latest_date)
        features : behaviour up to today
        output   : probability of NOT ordering in the NEXT 90 days

So features never see their own label window (no leakage) and the scores in
the database describe the future, not a stale past window.

Metrics saved to ml_model_metrics:
    auc                  - all customers (5-fold cross-validated, out-of-fold)
    auc_active_customers - only customers who were still active at the training
                           snapshot (the harder, more meaningful problem)
    auc_recency_only     - baseline: rank customers by days-since-last-order
                           (also reported for the active-customers subset)
    precision / recall / f1 for the churn class at threshold 0.5
"""

import logging
import sys
import warnings
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import xgboost as xgb
from sklearn.metrics import f1_score, precision_score, recall_score, roc_auc_score
from sklearn.model_selection import StratifiedKFold, cross_val_predict

sys.path.append(str(Path(__file__).resolve().parents[1]))
from db_connector import read_query, save_metrics, write_table  # noqa: E402

warnings.filterwarnings("ignore", category=UserWarning)
logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")
log = logging.getLogger("churn")

CHURN_WINDOW_DAYS = 90
SEED = 42


def load_orders() -> pd.DataFrame:
    df = read_query(
        """
        SELECT c.customer_id, c.age, c.region,
               d.full_date AS order_date, f.sales_amount, f.discount_pct, p.category
        FROM fact_sales f
        JOIN dim_customer c ON f.customer_key = c.customer_key
        JOIN dim_date d     ON f.date_key = d.date_key
        JOIN dim_product p  ON f.product_key = p.product_key
        """
    )
    df["order_date"] = pd.to_datetime(df["order_date"])
    return df


def snapshot_features(df: pd.DataFrame, as_of: pd.Timestamp, regions: list[str]) -> pd.DataFrame:
    """Features using ONLY orders on or before `as_of`."""
    hist = df[df["order_date"] <= as_of]
    last90 = hist[hist["order_date"] > as_of - pd.Timedelta(days=90)]
    prev90 = hist[(hist["order_date"] <= as_of - pd.Timedelta(days=90))
                  & (hist["order_date"] > as_of - pd.Timedelta(days=180))]

    agg = hist.groupby("customer_id").agg(
        total_orders=("order_date", "count"),
        total_spend=("sales_amount", "sum"),
        avg_order_value=("sales_amount", "mean"),
        avg_discount_used=("discount_pct", "mean"),
        n_categories=("category", "nunique"),
        first_order=("order_date", "min"),
        last_order=("order_date", "max"),
    )
    agg["recency_days"] = (as_of - agg["last_order"]).dt.days
    agg["tenure_days"] = (as_of - agg["first_order"]).dt.days
    agg["order_frequency"] = agg["total_orders"] / agg["tenure_days"].clip(lower=1)
    agg["orders_last_90d"] = last90.groupby("customer_id").size().reindex(agg.index).fillna(0)
    agg["orders_prev_90d"] = prev90.groupby("customer_id").size().reindex(agg.index).fillna(0)
    agg["order_trend"] = (agg["orders_last_90d"] + 1) / (agg["orders_prev_90d"] + 1)
    agg["spend_last_90d"] = last90.groupby("customer_id")["sales_amount"].sum().reindex(agg.index).fillna(0)

    meta = df.drop_duplicates("customer_id").set_index("customer_id")[["age", "region"]]
    agg = agg.join(meta)
    for r in regions:
        agg[f"region_{r}"] = (agg["region"] == r).astype(int)

    return agg.drop(columns=["first_order", "last_order", "region"]).reset_index()


def churn_labels(df: pd.DataFrame, as_of: pd.Timestamp, customer_ids: pd.Series) -> pd.Series:
    window = df[(df["order_date"] > as_of) & (df["order_date"] <= as_of + pd.Timedelta(days=CHURN_WINDOW_DAYS))]
    active = set(window["customer_id"].unique())
    return (~customer_ids.isin(active)).astype(int)


def new_model() -> xgb.XGBClassifier:
    return xgb.XGBClassifier(
        n_estimators=250, max_depth=3, learning_rate=0.05, subsample=0.8,
        colsample_bytree=0.8, min_child_weight=3, eval_metric="logloss",
        random_state=SEED, n_jobs=-1,
    )


def main() -> None:
    log.info("Loading order history...")
    df = load_orders()
    regions = sorted(df["region"].dropna().unique())
    max_date = df["order_date"].max()
    train_as_of = max_date - pd.Timedelta(days=CHURN_WINDOW_DAYS)

    # ---- training snapshot (labels are known) -------------------------------
    feats = snapshot_features(df, train_as_of, regions)
    feats["churned"] = churn_labels(df, train_as_of, feats["customer_id"]).values
    feature_cols = [c for c in feats.columns if c not in ("customer_id", "churned")]
    X, y = feats[feature_cols].fillna(0), feats["churned"]
    log.info("Training snapshot: %s | customers: %d | churn rate: %.1f%%",
             train_as_of.date(), len(feats), y.mean() * 100)

    # 5-fold stratified cross-validation: every customer gets an out-of-fold
    # prediction from a model that never saw them -> stable, honest metrics.
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=SEED)
    oof = cross_val_predict(new_model(), X, y, cv=cv, method="predict_proba")[:, 1]
    pred = (oof >= 0.5).astype(int)
    recency = X["recency_days"].values
    active_mask = recency <= CHURN_WINDOW_DAYS  # customers still active at the snapshot

    auc = roc_auc_score(y, oof)
    auc_recency = roc_auc_score(y, recency)
    auc_active = roc_auc_score(y[active_mask], oof[active_mask])
    auc_recency_active = roc_auc_score(y[active_mask], recency[active_mask])
    prec, rec, f1 = precision_score(y, pred), recall_score(y, pred), f1_score(y, pred)
    log.info("5-fold CV | AUC (all): %.3f | recency-only baseline: %.3f", auc, auc_recency)
    log.info("5-fold CV | AUC (active customers, n=%d): %.3f | recency-only baseline: %.3f",
             int(active_mask.sum()), auc_active, auc_recency_active)
    log.info("5-fold CV | churn class -> precision %.2f | recall %.2f | f1 %.2f", prec, rec, f1)

    importances = pd.Series(new_model().fit(X, y).feature_importances_, index=feature_cols).sort_values(ascending=False)
    log.info("Top churn drivers:\n%s", importances.head(6).round(3).to_string())

    # ---- refit on all labelled data, score TODAY's snapshot -----------------
    final_model = new_model().fit(X, y)
    today = snapshot_features(df, max_date, regions)
    probs = final_model.predict_proba(today[feature_cols].fillna(0))[:, 1]

    out = pd.DataFrame({
        "customer_id": today["customer_id"],
        "churn_probability": probs.round(4),
        "recency_days": today["recency_days"],
        "already_churned": (today["recency_days"] > CHURN_WINDOW_DAYS).astype(int),
    })
    out["churn_risk_band"] = pd.cut(out["churn_probability"], bins=[-0.01, 0.33, 0.66, 1.0],
                                    labels=["Low", "Medium", "High"]).astype(str)
    out["model_name"] = f"xgboost_churn_v2 (AUC={auc:.3f})"
    out["generated_at"] = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")

    write_table(out, "ml_customer_churn", if_exists="replace")
    n_at_risk = int(((out["churn_risk_band"] == "High") & (out["already_churned"] == 0)).sum())
    log.info("Scored %d customers | still-active but HIGH risk: %d", len(out), n_at_risk)

    note = f"5-fold CV out-of-fold, snapshot {train_as_of.date()}"
    save_metrics("churn", [
        {"model": "xgboost", "metric": "auc", "value": auc, "note": note},
        {"model": "xgboost", "metric": "auc_active_customers", "value": auc_active, "note": "5-fold CV, only customers active at snapshot"},
        {"model": "recency_only_baseline", "metric": "auc", "value": auc_recency, "note": note},
        {"model": "recency_only_baseline", "metric": "auc_active_customers", "value": auc_recency_active, "note": "5-fold CV, only customers active at snapshot"},
        {"model": "xgboost", "metric": "precision", "value": prec, "note": "churn class, threshold 0.5"},
        {"model": "xgboost", "metric": "recall", "value": rec, "note": "churn class, threshold 0.5"},
        {"model": "xgboost", "metric": "f1", "value": f1, "note": "churn class, threshold 0.5"},
        {"model": "xgboost", "metric": "train_churn_rate", "value": float(y.mean()), "note": "share of churned customers"},
        {"model": "xgboost", "metric": "high_risk_active_customers", "value": n_at_risk, "note": "actionable retention list"},
    ])


if __name__ == "__main__":
    main()
