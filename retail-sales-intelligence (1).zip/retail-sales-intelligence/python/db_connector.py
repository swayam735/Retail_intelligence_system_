"""
db_connector.py
----------------
Single shared utility so every module (ML scripts, API, dashboard) reads
from / writes to the warehouse the same way.

Config:
    RETAIL_DB_PATH   (optional) override the SQLite file location, e.g.
                     RETAIL_DB_PATH=/data/warehouse.db

To move to SQL Server / Postgres, only this file changes: replace
get_connection() with a SQLAlchemy engine - callers don't change.
"""

import os
import sqlite3
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DB_PATH = Path(os.environ.get("RETAIL_DB_PATH", ROOT / "data" / "warehouse.db"))


def get_connection() -> sqlite3.Connection:
    if not DB_PATH.exists():
        raise FileNotFoundError(
            f"Warehouse not found at {DB_PATH}. Run `python run_pipeline.py` first."
        )
    return sqlite3.connect(DB_PATH)


def read_query(query: str, params=None) -> pd.DataFrame:
    """Run a SELECT. Always pass user-supplied values via `params` (never f-strings)."""
    with closing(get_connection()) as conn:
        return pd.read_sql(query, conn, params=params)


def write_table(df: pd.DataFrame, table_name: str, if_exists: str = "replace") -> None:
    with closing(get_connection()) as conn:
        df.to_sql(table_name, conn, if_exists=if_exists, index=False)


def save_metrics(task: str, metrics: list[dict]) -> None:
    """
    Persist model metrics to ml_model_metrics so they show up in Power BI /
    the dashboard / the API and can be asserted on in tests.

    metrics: [{"model": "blend", "metric": "mape_pct", "value": 9.7, "note": "..."}, ...]
    Replaces previous rows for the same task (idempotent re-runs).
    """
    run_at = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    df = pd.DataFrame(metrics)
    df["task"] = task
    df["run_at"] = run_at
    if "note" not in df.columns:
        df["note"] = ""
    df = df[["task", "model", "metric", "value", "note", "run_at"]]

    with closing(get_connection()) as conn:
        conn.execute(
            """CREATE TABLE IF NOT EXISTS ml_model_metrics (
                   task TEXT, model TEXT, metric TEXT, value REAL, note TEXT, run_at TEXT)"""
        )
        conn.execute("DELETE FROM ml_model_metrics WHERE task = ?", (task,))
        df.to_sql("ml_model_metrics", conn, if_exists="append", index=False)
        conn.commit()
