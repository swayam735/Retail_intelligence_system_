-- =====================================================================
-- create_views.sql
-- Reusable views, created right after the warehouse is loaded.
-- Power BI, the Streamlit dashboard and the REST API all read these, so
-- business logic lives in ONE place (SQL), not in three front-ends.
-- (In SQL Server some of these would be stored procedures.)
-- =====================================================================

DROP VIEW IF EXISTS vw_monthly_kpi_summary;
CREATE VIEW vw_monthly_kpi_summary AS
SELECT
    d.year,
    d.month,
    d.month_name,
    printf('%04d-%02d', d.year, d.month) AS year_month,
    COUNT(DISTINCT f.order_id)           AS orders,
    ROUND(SUM(f.sales_amount), 2)        AS revenue,
    ROUND(AVG(f.sales_amount), 2)        AS avg_order_value,
    ROUND(SUM(CASE WHEN f.promo_flag = 1 THEN f.sales_amount ELSE 0 END), 2) AS promo_revenue
FROM fact_sales f
JOIN dim_date d ON f.date_key = d.date_key
GROUP BY d.year, d.month, d.month_name;

DROP VIEW IF EXISTS vw_daily_sales;
CREATE VIEW vw_daily_sales AS
SELECT
    d.full_date                      AS sales_date,
    ROUND(SUM(f.sales_amount), 2)    AS revenue,
    COUNT(DISTINCT f.order_id)       AS orders
FROM fact_sales f
JOIN dim_date d ON f.date_key = d.date_key
GROUP BY d.full_date;

DROP VIEW IF EXISTS vw_product_performance;
CREATE VIEW vw_product_performance AS
SELECT
    p.category,
    p.product_name,
    SUM(f.quantity)                                   AS units_sold,
    ROUND(SUM(f.sales_amount), 2)                     AS revenue,
    ROUND(SUM(f.sales_amount - f.quantity * p.unit_cost), 2) AS gross_profit,
    ROUND(AVG(f.discount_pct), 4)                     AS avg_discount
FROM fact_sales f
JOIN dim_product p ON f.product_key = p.product_key
GROUP BY p.category, p.product_name;

DROP VIEW IF EXISTS vw_customer_360;
CREATE VIEW vw_customer_360 AS
SELECT
    c.customer_id, c.customer_name, c.region, c.age_band,
    ch.churn_probability, ch.churn_risk_band, ch.already_churned,
    sg.rfm_segment, sg.recency_days, sg.frequency, sg.monetary
FROM dim_customer c
LEFT JOIN ml_customer_churn    ch ON c.customer_id = ch.customer_id
LEFT JOIN ml_customer_segments sg ON c.customer_id = sg.customer_id;
