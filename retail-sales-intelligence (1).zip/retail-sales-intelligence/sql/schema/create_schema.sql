-- =====================================================================
-- create_schema.sql
-- Star schema for the Retail Sales Intelligence warehouse.
-- Portable SQL (SQLite syntax here; notes for SQL Server/Postgres inline).
-- =====================================================================

DROP TABLE IF EXISTS fact_sales;
DROP TABLE IF EXISTS dim_customer;
DROP TABLE IF EXISTS dim_product;
DROP TABLE IF EXISTS dim_store;
DROP TABLE IF EXISTS dim_date;

-- ---------------------------------------------------------------------
-- DIM: Date  (standard BI date dimension, pre-populated by ETL)
-- ---------------------------------------------------------------------
CREATE TABLE dim_date (
    date_key        INTEGER PRIMARY KEY,   -- YYYYMMDD
    full_date       DATE NOT NULL,
    day             INTEGER NOT NULL,
    month           INTEGER NOT NULL,
    month_name      TEXT NOT NULL,
    quarter         INTEGER NOT NULL,
    year             INTEGER NOT NULL,
    day_of_week     INTEGER NOT NULL,      -- 0=Mon ... 6=Sun
    day_name        TEXT NOT NULL,
    is_weekend      INTEGER NOT NULL       -- 0/1
);

-- ---------------------------------------------------------------------
-- DIM: Customer
-- ---------------------------------------------------------------------
CREATE TABLE dim_customer (
    customer_key    INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id     INTEGER NOT NULL UNIQUE,
    customer_name   TEXT NOT NULL,
    signup_date     DATE,
    region          TEXT,
    age             INTEGER,
    age_band        TEXT                    -- derived: 18-25, 26-35, etc.
);

-- ---------------------------------------------------------------------
-- DIM: Product
-- ---------------------------------------------------------------------
CREATE TABLE dim_product (
    product_key     INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id      INTEGER NOT NULL UNIQUE,
    product_name    TEXT NOT NULL,
    category        TEXT,
    unit_cost       REAL,
    unit_price      REAL,
    margin_pct      REAL                    -- derived: (price-cost)/price
);

-- ---------------------------------------------------------------------
-- DIM: Store
-- ---------------------------------------------------------------------
CREATE TABLE dim_store (
    store_key       INTEGER PRIMARY KEY AUTOINCREMENT,
    store_id        INTEGER NOT NULL UNIQUE,
    store_name      TEXT NOT NULL,
    region          TEXT,
    city            TEXT
);

-- ---------------------------------------------------------------------
-- FACT: Sales  (grain = one row per order line)
-- ---------------------------------------------------------------------
CREATE TABLE fact_sales (
    sales_key       INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id        INTEGER NOT NULL,
    date_key        INTEGER NOT NULL REFERENCES dim_date(date_key),
    customer_key    INTEGER NOT NULL REFERENCES dim_customer(customer_key),
    product_key     INTEGER NOT NULL REFERENCES dim_product(product_key),
    store_key       INTEGER NOT NULL REFERENCES dim_store(store_key),
    quantity        INTEGER NOT NULL,
    unit_price      REAL NOT NULL,
    discount_pct    REAL DEFAULT 0,
    sales_amount    REAL NOT NULL,
    promo_flag      INTEGER DEFAULT 0
);

-- ---------------------------------------------------------------------
-- Indexes: fact table foreign keys are the most common join/filter paths.
-- (SQL Server: CREATE NONCLUSTERED INDEX ...; Postgres: same CREATE INDEX)
-- ---------------------------------------------------------------------
CREATE INDEX idx_fact_sales_date     ON fact_sales(date_key);
CREATE INDEX idx_fact_sales_customer ON fact_sales(customer_key);
CREATE INDEX idx_fact_sales_product  ON fact_sales(product_key);
CREATE INDEX idx_fact_sales_store    ON fact_sales(store_key);

-- ---------------------------------------------------------------------
-- ML output tables (written by the Python layer, re-created on every run
-- of the models; the DDL here documents the contract Power BI / the API rely on)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS ml_sales_forecast;
CREATE TABLE ml_sales_forecast (
    forecast_date   TEXT NOT NULL,          -- YYYY-MM-DD
    predicted_sales REAL NOT NULL,
    lower_bound     REAL,                   -- approx. 80% prediction interval
    upper_bound     REAL,
    actual_sales    REAL,                   -- filled for record_type = 'backtest'
    record_type     TEXT,                   -- 'backtest' | 'forecast'
    model_name      TEXT,
    generated_at    TEXT
);

DROP TABLE IF EXISTS ml_customer_churn;
CREATE TABLE ml_customer_churn (
    customer_id       INTEGER NOT NULL,
    churn_probability REAL NOT NULL,        -- P(no order in the NEXT 90 days)
    recency_days      INTEGER,
    already_churned   INTEGER,              -- 1 if no order for > 90 days
    churn_risk_band   TEXT,                 -- Low / Medium / High
    model_name        TEXT,
    generated_at      TEXT
);

DROP TABLE IF EXISTS ml_customer_segments;
CREATE TABLE ml_customer_segments (
    customer_id     INTEGER NOT NULL,
    recency_days    INTEGER,
    frequency       INTEGER,
    monetary        REAL,
    rfm_segment     TEXT                    -- Champions, Loyal Customers, At Risk, Lost, ...
);

DROP TABLE IF EXISTS ml_model_metrics;
CREATE TABLE ml_model_metrics (
    task    TEXT,                           -- forecast | churn
    model   TEXT,
    metric  TEXT,
    value   REAL,
    note    TEXT,
    run_at  TEXT
);
