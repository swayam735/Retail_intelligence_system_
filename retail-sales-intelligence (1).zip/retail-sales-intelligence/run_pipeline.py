"""
run_pipeline.py
----------------
One command to build everything:

    python run_pipeline.py

Stages
    1. Generate synthetic raw data
    2. Build the SQL warehouse (schema + ETL) and the analytical views
    3. Train / score the 3 ML models (forecast, churn, RFM segmentation)
    4. Export tables for Power BI (Excel workbook + CSVs)
    5. Print a results summary

Works on Windows / macOS / Linux (uses the same Python interpreter that
launched it, so virtual environments are respected).
"""

import argparse
import logging
import sqlite3
import subprocess
import sys
import time
from pathlib import Path

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")
log = logging.getLogger("pipeline")

ROOT = Path(__file__).resolve().parent
DB_PATH = ROOT / "data" / "warehouse.db"
VIEWS_SQL = ROOT / "sql" / "analytics" / "create_views.sql"
PY = sys.executable

STEPS = [
    ("Generating synthetic raw data", [PY, "data/generate_data.py"]),
    ("Building SQL warehouse (schema + ETL)", [PY, "sql/etl/load_data.py"]),
    ("Creating SQL views", None),  # handled in-process
    ("Training sales forecast model (tuning takes ~30-60s)", [PY, "python/forecasting/train_forecast.py"]),
    ("Training churn model", [PY, "python/churn_model/train_churn.py"]),
    ("Running RFM customer segmentation", [PY, "python/segmentation/rfm_segmentation.py"]),
    ("Exporting tables for Power BI", [PY, "powerbi/export_for_powerbi.py"]),
]


def create_views() -> None:
    conn = sqlite3.connect(DB_PATH)
    try:
        conn.executescript(VIEWS_SQL.read_text(encoding="utf-8"))
        conn.commit()
    finally:
        conn.close()


def run_step(index: int, total: int, name: str, cmd) -> None:
    log.info("[%d/%d] %s", index, total, name)
    start = time.time()
    if cmd is None:
        create_views()
    else:
        result = subprocess.run(cmd, cwd=ROOT)
        if result.returncode != 0:
            log.error("FAILED: %s (exit code %d). Scroll up for the error.", name, result.returncode)
            sys.exit(result.returncode)
    log.info("      done in %.1fs", time.time() - start)


def print_summary() -> None:
    sys.path.append(str(ROOT / "python"))
    from db_connector import read_query

    m = read_query("SELECT task, model, metric, value, note FROM ml_model_metrics")

    def val(task, model, metric, note_contains=""):
        sel = m[(m.task == task) & (m.model == model) & (m.metric == metric)]
        if note_contains:
            sel = sel[sel.note.str.contains(note_contains, regex=False)]
        return float(sel["value"].iloc[0])

    fc = lambda model, note="one-step": val("forecast", model, "mape_pct", note)  # noqa: E731
    print("\n" + "=" * 66)
    print(" RESULTS SUMMARY")
    print("=" * 66)
    print(" Sales forecast - MAPE, 60-day holdout (lower is better)")
    for name in ["naive (yesterday)", "seasonal_naive (last week)", "moving_avg_7d",
                 "same_weekday_4w_avg", "blend (final)"]:
        print(f"   {name:<30}{fc(name):>7.2f}%")
    print(f"   -> improvement vs naive: {val('forecast', 'blend (final)', 'improvement_vs_naive_pct'):.1f}% | "
          f"vs best baseline: {val('forecast', 'blend (final)', 'improvement_vs_best_baseline_pct'):.1f}%")
    print(f"   -> recursive 60-day-ahead MAPE: {fc('blend (final)', 'recursive'):.2f}% "
          f"(baseline {fc('same_weekday_4w_avg', 'recursive'):.2f}%)")
    print(" Churn model")
    print(f"   AUC (all customers)            {val('churn', 'xgboost', 'auc'):.3f}   "
          f"[recency-only baseline {val('churn', 'recency_only_baseline', 'auc'):.3f}]")
    print(f"   AUC (active customers only)    {val('churn', 'xgboost', 'auc_active_customers'):.3f}   "
          f"[recency-only baseline {val('churn', 'recency_only_baseline', 'auc_active_customers'):.3f}]")
    print(f"   precision / recall (churn)     {val('churn', 'xgboost', 'precision'):.2f} / {val('churn', 'xgboost', 'recall'):.2f}")
    print("=" * 66)
    print(" Next:  python -m pytest -q          (run tests)")
    print("        streamlit run dashboard/app.py   (interactive dashboard)")
    print("        uvicorn api.main:app --reload     (REST API at /docs)")
    print("        Power BI: powerbi/exports/retail_powerbi_data.xlsx")
    print("=" * 66 + "\n")


def main() -> None:
    parser = argparse.ArgumentParser(description="Build the whole project end-to-end.")
    parser.add_argument("--skip-generate", action="store_true",
                        help="don't create synthetic data; use your own CSVs already placed in data/raw/")
    args = parser.parse_args()

    steps = STEPS[1:] if args.skip_generate else STEPS
    if args.skip_generate:
        needed = ["customers.csv", "products.csv", "stores.csv", "sales.csv"]
        missing = [f for f in needed if not (ROOT / "data" / "raw" / f).exists()]
        if missing:
            log.error("--skip-generate needs these files in data/raw/: %s", ", ".join(missing))
            sys.exit(2)

    t0 = time.time()
    for i, (name, cmd) in enumerate(steps, 1):
        run_step(i, len(steps), name, cmd)
    log.info("Pipeline finished in %.0fs. Warehouse: %s", time.time() - t0, DB_PATH)
    print_summary()


if __name__ == "__main__":
    main()
