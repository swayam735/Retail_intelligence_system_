# Architecture

```mermaid
flowchart TD
    A[data/generate_data.py<br/>synthetic, intentionally messy] --> B[(data/raw/*.csv)]
    B --> C[sql/etl/load_data.py<br/>dedupe, validate, derive columns]
    C --> D[(SQLite warehouse<br/>fact_sales + dim_date/customer/product/store)]
    D --> V[SQL views<br/>vw_monthly_kpi_summary, vw_daily_sales,<br/>vw_product_performance, vw_customer_360]
    D --> F[Forecast: tuned XGBoost + Ridge on ratio target]
    D --> H[Churn: snapshot-based XGBoost, 5-fold CV]
    D --> K[RFM + K-Means segmentation]
    F --> T1[(ml_sales_forecast)]
    H --> T2[(ml_customer_churn)]
    K --> T3[(ml_customer_segments)]
    F & H --> T4[(ml_model_metrics)]
    T1 & T2 & T3 & T4 --> D
    V --> API[FastAPI<br/>api/main.py]
    V --> DASH[Streamlit<br/>dashboard/app.py]
    V --> PBI[Power BI<br/>retail_powerbi_data.xlsx]
```

## Design decisions
1. **SQL owns structure and business logic.** Views are the contract; API, dashboard and Power BI never re-implement KPIs.
2. **Predictions live in tables, not pickles.** Any BI tool can consume them; metrics are stored next to them (`ml_model_metrics`) and asserted on in tests.
3. **Leakage prevention.** Forecast: a single `feature_row()` shared by training and recursive prediction. Churn: snapshot training (features at T-90, label in next 90 days) and scoring at T.
4. **Honest evaluation.** Four baselines, a never-touched holdout, a multi-step (recursive) backtest, and cross-validated churn metrics with a recency-only baseline.
5. **One DB-specific file.** `python/db_connector.py` — swap SQLite for SQL Server/Postgres there.
