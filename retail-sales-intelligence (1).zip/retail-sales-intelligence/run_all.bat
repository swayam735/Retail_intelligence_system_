@echo off
REM Windows: build everything (data -> SQL warehouse -> ML -> Power BI export) and run tests.
call .venv\Scripts\activate.bat
python run_pipeline.py || (echo Pipeline failed & pause & exit /b 1)
python -m pytest -q
echo.
echo Power BI file ready: powerbi\exports\retail_powerbi_data.xlsx
pause
