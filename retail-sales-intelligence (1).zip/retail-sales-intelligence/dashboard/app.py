"""
Interactive dashboard (Streamlit).

Run:   streamlit run dashboard/app.py
Needs: `python run_pipeline.py` to have been run once (builds the warehouse).

It reads the same SQL views Power BI uses, so the numbers always match.
"""

import sys
from pathlib import Path

import altair as alt
import pandas as pd
import streamlit as st

sys.path.append(str(Path(__file__).resolve().parents[1] / "python"))
from db_connector import DB_PATH, read_query  # noqa: E402

st.set_page_config(page_title="Retail Sales Intelligence", page_icon="📊", layout="wide")


@st.cache_data(ttl=300, show_spinner=False)
def q(sql: str, params: tuple = ()) -> pd.DataFrame:
    return read_query(sql, params=params or None)


# ----------------------------------------------------------------------------
# Guard: friendly message instead of a stack trace if the warehouse is missing
# ----------------------------------------------------------------------------
if not DB_PATH.exists():
    st.error("Warehouse not found. Run `python run_pipeline.py` first, then refresh this page.")
    st.stop()

st.title("📊 Retail Sales Intelligence")
st.caption("SQL warehouse → ML models → live dashboard. All numbers come from the SQL views.")

# ----------------------------------------------------------------------------
# Sidebar filter
# ----------------------------------------------------------------------------
years = q("SELECT DISTINCT year FROM vw_monthly_kpi_summary ORDER BY year")["year"].tolist()
year_choice = st.sidebar.selectbox("Year", ["All years"] + years, index=len(years))
st.sidebar.markdown("---")
st.sidebar.caption(f"Warehouse: `{DB_PATH.name}`")

year_filter = "" if year_choice == "All years" else "WHERE d.year = ?"
year_params: tuple = () if year_choice == "All years" else (int(year_choice),)

tab_overview, tab_forecast, tab_customers, tab_products, tab_quality = st.tabs(
    ["Overview", "Sales forecast", "Customers", "Products", "Model quality"]
)

# ----------------------------------------------------------------------------
# Overview
# ----------------------------------------------------------------------------
with tab_overview:
    kpi = q(
        f"""SELECT SUM(f.sales_amount) AS revenue, COUNT(DISTINCT f.order_id) AS orders,
                   COUNT(DISTINCT f.customer_key) AS customers
            FROM fact_sales f JOIN dim_date d ON f.date_key = d.date_key {year_filter}""",
        year_params,
    ).iloc[0]
    aov = kpi["revenue"] / max(kpi["orders"], 1)

    delta = None
    if year_choice != "All years":
        prev = q(
            "SELECT SUM(f.sales_amount) AS revenue FROM fact_sales f "
            "JOIN dim_date d ON f.date_key = d.date_key WHERE d.year = ?",
            (int(year_choice) - 1,),
        ).iloc[0]["revenue"]
        if prev and prev > 0:
            delta = f"{(kpi['revenue'] / prev - 1) * 100:+.1f}% vs {int(year_choice) - 1}"

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Revenue", f"₹{kpi['revenue']:,.0f}", delta)
    c2.metric("Orders", f"{int(kpi['orders']):,}")
    c3.metric("Avg order value", f"₹{aov:,.0f}")
    c4.metric("Active customers", f"{int(kpi['customers']):,}")

    monthly = q(
        f"""SELECT year_month, revenue FROM vw_monthly_kpi_summary
            {'' if year_choice == 'All years' else 'WHERE year = ?'} ORDER BY year_month""",
        year_params,
    )
    st.subheader("Monthly revenue")
    st.altair_chart(
        alt.Chart(monthly).mark_line(point=True).encode(
            x=alt.X("year_month:O", title="Month"), y=alt.Y("revenue:Q", title="Revenue"),
            tooltip=["year_month", alt.Tooltip("revenue:Q", format=",.0f")],
        ).properties(height=320),
        width="stretch",
    )

    region = q(
        f"""SELECT s.region, SUM(f.sales_amount) AS revenue
            FROM fact_sales f JOIN dim_store s ON f.store_key = s.store_key
            JOIN dim_date d ON f.date_key = d.date_key {year_filter}
            GROUP BY s.region ORDER BY revenue DESC""",
        year_params,
    )
    st.subheader("Revenue by region")
    st.altair_chart(
        alt.Chart(region).mark_bar().encode(
            x=alt.X("revenue:Q", title="Revenue"), y=alt.Y("region:N", sort="-x", title=None),
            tooltip=["region", alt.Tooltip("revenue:Q", format=",.0f")],
        ).properties(height=220),
        width="stretch",
    )

# ----------------------------------------------------------------------------
# Forecast
# ----------------------------------------------------------------------------
with tab_forecast:
    st.subheader("90-day sales forecast")
    fc = q("SELECT * FROM ml_sales_forecast ORDER BY forecast_date")
    fc["forecast_date"] = pd.to_datetime(fc["forecast_date"])
    hist = q("SELECT sales_date, revenue FROM vw_daily_sales ORDER BY sales_date DESC LIMIT 150")
    hist["sales_date"] = pd.to_datetime(hist["sales_date"])

    backtest = fc[fc["record_type"] == "backtest"]
    future = fc[fc["record_type"] == "forecast"]

    actual_df = hist.rename(columns={"sales_date": "date", "revenue": "value"}).assign(series="Actual")
    bt_df = backtest.rename(columns={"forecast_date": "date", "predicted_sales": "value"})[["date", "value"]].assign(series="Backtest (60-day-ahead)")
    fut_df = future.rename(columns={"forecast_date": "date", "predicted_sales": "value"})[["date", "value"]].assign(series="Forecast")
    lines = pd.concat([actual_df, bt_df, fut_df])

    colors = alt.Scale(domain=["Actual", "Backtest (60-day-ahead)", "Forecast"], range=["#1f77b4", "#ff7f0e", "#2ca02c"])
    band = alt.Chart(future.rename(columns={"forecast_date": "date"})).mark_area(opacity=0.18, color="#2ca02c").encode(
        x="date:T", y=alt.Y("lower_bound:Q", title="Daily revenue"), y2="upper_bound:Q")
    line = alt.Chart(lines).mark_line().encode(
        x=alt.X("date:T", title=None), y="value:Q",
        color=alt.Color("series:N", scale=colors, legend=alt.Legend(title=None, orient="top")),
        tooltip=["series", "date:T", alt.Tooltip("value:Q", format=",.0f")])
    st.altair_chart((band + line).properties(height=380), width="stretch")
    st.caption("Shaded band = approximate 80% prediction interval, calibrated on a multi-step backtest.")

    total_next30 = future.head(30)["predicted_sales"].sum()
    m1, m2 = st.columns(2)
    m1.metric("Forecast revenue, next 30 days", f"₹{total_next30:,.0f}")
    m2.metric("Forecast revenue, next 90 days", f"₹{future['predicted_sales'].sum():,.0f}")

    with st.expander("Next 14 days (table)"):
        table = future.head(14)[["forecast_date", "predicted_sales", "lower_bound", "upper_bound"]].copy()
        table["forecast_date"] = table["forecast_date"].dt.strftime("%a %d %b %Y")
        st.dataframe(table.round(0), hide_index=True, width="stretch")

# ----------------------------------------------------------------------------
# Customers
# ----------------------------------------------------------------------------
with tab_customers:
    seg = q("SELECT rfm_segment, COUNT(*) AS customers, ROUND(AVG(monetary),0) AS avg_spend "
            "FROM ml_customer_segments GROUP BY rfm_segment ORDER BY customers DESC")
    left, right = st.columns(2)
    with left:
        st.subheader("RFM segments")
        st.altair_chart(
            alt.Chart(seg).mark_bar().encode(
                x=alt.X("customers:Q"), y=alt.Y("rfm_segment:N", sort="-x", title=None),
                tooltip=["rfm_segment", "customers", alt.Tooltip("avg_spend:Q", format=",.0f")],
            ).properties(height=260),
            width="stretch",
        )
    with right:
        st.subheader("Churn risk (still-active customers)")
        band = q("SELECT churn_risk_band, COUNT(*) AS customers FROM ml_customer_churn "
                 "WHERE already_churned = 0 GROUP BY churn_risk_band")
        order = ["Low", "Medium", "High"]
        st.altair_chart(
            alt.Chart(band).mark_bar().encode(
                x=alt.X("churn_risk_band:N", sort=order, title=None), y="customers:Q",
                color=alt.Color("churn_risk_band:N", sort=order, legend=None,
                                scale=alt.Scale(domain=order, range=["#2ca02c", "#ffbf00", "#d62728"])),
                tooltip=["churn_risk_band", "customers"],
            ).properties(height=260),
            width="stretch",
        )

    st.subheader("Retention call list: active customers with the highest churn probability")
    risky = q("SELECT customer_id, customer_name, region, rfm_segment, churn_probability, recency_days, monetary "
              "FROM vw_customer_360 WHERE already_churned = 0 ORDER BY churn_probability DESC LIMIT 25")
    st.dataframe(risky, hide_index=True, width="stretch")
    already = q("SELECT COUNT(*) AS n FROM ml_customer_churn WHERE already_churned = 1").iloc[0]["n"]
    st.caption(f"{int(already):,} customers have not ordered for 90+ days (already churned) and are excluded above.")

# ----------------------------------------------------------------------------
# Products
# ----------------------------------------------------------------------------
with tab_products:
    cat = q("SELECT category, SUM(revenue) AS revenue, SUM(gross_profit) AS gross_profit "
            "FROM vw_product_performance GROUP BY category ORDER BY revenue DESC")
    st.subheader("Revenue and gross profit by category")
    st.altair_chart(
        alt.Chart(cat.melt("category", var_name="measure", value_name="amount")).mark_bar().encode(
            x=alt.X("category:N", title=None), y=alt.Y("amount:Q", title=None),
            xOffset="measure:N", color=alt.Color("measure:N", legend=alt.Legend(title=None, orient="top")),
            tooltip=["category", "measure", alt.Tooltip("amount:Q", format=",.0f")],
        ).properties(height=320),
        width="stretch",
    )
    st.subheader("Top 10 products by revenue")
    st.dataframe(q("SELECT product_name, category, units_sold, revenue, gross_profit "
                   "FROM vw_product_performance ORDER BY revenue DESC LIMIT 10"),
                 hide_index=True, width="stretch")
    promo = q("SELECT CASE promo_flag WHEN 1 THEN 'On promotion' ELSE 'Regular price' END AS pricing, "
              "ROUND(AVG(sales_amount),0) AS avg_order_line_value, COUNT(*) AS lines FROM fact_sales GROUP BY promo_flag")
    st.subheader("Promotion vs regular price")
    st.dataframe(promo, hide_index=True, width="stretch")

# ----------------------------------------------------------------------------
# Model quality (transparency tab - great to show in interviews)
# ----------------------------------------------------------------------------
with tab_quality:
    st.subheader("Forecast accuracy vs baselines (MAPE %, lower is better)")
    st.caption("One-step-ahead on a 60-day holdout the model never saw during tuning or blending.")
    m = q("SELECT model, value FROM ml_model_metrics WHERE task='forecast' AND metric='mape_pct' "
          "AND note LIKE 'one-step%' ORDER BY value")
    st.altair_chart(
        alt.Chart(m).mark_bar().encode(
            x=alt.X("value:Q", title="MAPE %"), y=alt.Y("model:N", sort="x", title=None),
            color=alt.condition(alt.datum.model == "blend (final)", alt.value("#2ca02c"), alt.value("#9aa5b1")),
            tooltip=["model", alt.Tooltip("value:Q", format=".2f")],
        ).properties(height=260),
        width="stretch",
    )
    rec = q("SELECT model, value FROM ml_model_metrics WHERE task='forecast' AND metric='mape_pct' AND note LIKE 'recursive%'")
    if not rec.empty:
        st.caption("Realistic multi-step setting (forecasting all 60 days at once): " +
                   " | ".join(f"{r.model}: {r.value:.2f}%" for r in rec.itertuples()))

    st.subheader("Churn model (5-fold cross-validated)")
    st.dataframe(q("SELECT model, metric, ROUND(value, 3) AS value, note FROM ml_model_metrics "
                   "WHERE task='churn' ORDER BY metric, model"), hide_index=True, width="stretch")
    st.info("Honest reading: the churn model matches a simple recency-only baseline on this synthetic data. "
            "Recency is the dominant signal; the value of the model is the deployed, explainable scoring pipeline.")
